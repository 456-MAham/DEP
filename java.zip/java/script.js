const accordionBtns = document.querySelectorAll(".item-header");
accordionBtns.forEach((accordion) => {
    accordion.onclick = function () {
        this.classList.toggle("active");
        let content = this.nextElementSibling;
        if (content.style.maxHeight) {
            content.style.maxHeight = null;
        } else {
            content.style.maxHeight = content.scrollHeight + "px";
        }
    };
});